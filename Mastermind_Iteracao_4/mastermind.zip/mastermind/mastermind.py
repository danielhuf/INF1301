# Bruno Abtibol Ramos
# Daniel Stulberg Huf
# João Pedro Khair Cunha

import tkinter
from view import janelaInicial

#Criação da janela principal
menu = tkinter.Tk()
janelaInicial.inicia(menu)
menu.mainloop()
